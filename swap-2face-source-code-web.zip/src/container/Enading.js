function Ending() {
    return <div>hello ending</div>;
}

export default Ending;
